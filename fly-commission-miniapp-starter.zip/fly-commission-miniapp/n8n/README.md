# n8n: kết nối Google Sheets + Google Drive + Telegram

Đây là hướng dẫn ráp workflow với credential thật của bạn. Các tên cột trong phần dưới là tên gợi ý; phải sửa theo hàng tiêu đề thực tế của sheet. Ảnh hiện tại chỉ thấy tab `Hướng dẫn`, nên không thể bảo đảm mapping cột nào là đúng khi chưa xem header rows của các tab dữ liệu.

**Spreadsheet ID:** `115wok3QehyifvVRtCi7a8Oz4D5r3dTu9OWpiwb_-O30`

## A. Chuẩn bị trước

1. Trong n8n Cloud, tạo Google Sheets credential, Google Drive credential và Telegram credential cho đúng tài khoản.
2. Đảm bảo Google account đã kết nối có quyền Editor với spreadsheet và quyền tạo file/folder tại hai thư mục gốc trên Drive.
3. Tạo/ chọn group kế toán. Lấy Chat ID; group/supergroup thường có ID âm, dạng `-100...`. Giữ nguyên dấu `-`.
4. Tạo hai thư mục gốc trên Drive nếu chưa có: `2. CCCD đại lý` và `3. Chứng từ chuyển khoản`. Ghi lại folder ID của hai thư mục.
5. Chọn một secret ngẫu nhiên dài. Dùng chính secret này ở Vercel `N8N_WEBHOOK_SECRET` và trong n8n Header Auth credential.
6. Xem hàng tiêu đề (header row) của các tab `Đối tác all time`, `Đại lý Phát sinh`, `Lịch sử chứng từ`; mở `snippets/normalize-agent-list.js` và `snippets/resolve-agent-and-duplicates.js`, sửa các mảng alias `FIELD` khớp đúng tiêu đề.
7. Thêm các cột quản lý lệnh vào **cuối** tab `Lịch sử chứng từ` nếu chưa có, không chèn giữa cột hiện tại:

   - `Mã hoa hồng`
   - `Trạng thái chi`
   - `Ngày tạo lệnh`
   - `Telegram ID người tạo`
   - `Người tạo`
   - `Người duyệt`
   - `Thời điểm duyệt`
   - `Người chuyển`
   - `Thời điểm chuyển`
   - `Link folder CCCD`
   - `Link folder CK`
   - `Ghi chú`

8. **Không ghi vào các cột tự tính** trong sheet lịch sử như STT, tên, CCCD, ngân hàng, STK và tên file chứng từ CK nếu chúng được tự động điền bằng công thức. Node Append Row chỉ điền những cột nhập tay + cột hệ thống mới.

## B. Workflow 1 — `Commission - Get Agents`

Mục đích: Mini App nhận danh sách đại lý khi mở form.

### Node 1: Webhook `GET /commission-agents`

- HTTP Method: `GET`
- Path: `commission-agents`
- Authentication: `Header Auth`
- Header Auth credential: Name `x-commission-secret`, Value bằng `N8N_WEBHOOK_SECRET`
- Respond: `Using Respond to Webhook Node`
- Activate workflow; dùng **Production URL**, không dùng Test URL, trong Vercel.

### Node 2: Google Sheets `Read All Time`

- Resource: Sheet Within Document
- Operation: Get Row(s) / Read Rows
- Document: spreadsheet phía trên
- Sheet: `Đối tác all time`
- Đọc data rows, bỏ hàng header theo cài đặt node.

### Node 3: Google Sheets `Read Phat Sinh`

- Cấu hình tương tự, Sheet: `Đại lý Phát sinh`.
- Nối tuần tự sau `Read All Time` để hai node đều được chạy trước Code node.

### Node 4: Code `Normalize Agent List`

- Mode: Run Once for All Items
- Dán toàn bộ `n8n/snippets/normalize-agent-list.js`.
- Sửa `FIELD` aliases khớp header thật.
- Code kết hợp `Đối tác all time` (danh sách mã chính) và `Đại lý Phát sinh` (có thể có thông tin CCCD/ngân hàng đầy đủ hơn).

### Node 5: Respond to Webhook

- Respond With: JSON
- Response Body: `={{ $json }}`
- Response Code: `200`

Đầu ra phải là `{"agents":[{"code":"DL170","name":"...","cccd":"...","bankName":"...","accountNumber":"...","accountHolder":"..."}]}`. Nếu client báo không tải được danh sách, mở Executions và kiểm tra tiêu đề/cột mapping.

## C. Workflow 2 — `Commission - Create Order`

Mục đích: xác thực dữ liệu đại lý, cập nhật hồ sơ, tạo lịch sử chứng từ, tạo các folder cần thiết, gửi tin nhắn vào group.

### Node 1: Webhook `POST /commission-create`

- HTTP Method: `POST`
- Path: `commission-create`
- Authentication: Header Auth (`x-commission-secret`)
- Respond: `Using Respond to Webhook Node`
- Gửi dữ liệu multipart/form-data. Sau lần gửi test đầu tiên, mở output Webhook để xác nhận text nằm trong `$json.body` và file nằm trong `$binary`. Nếu n8n version của bạn đặt trường khác, sửa Code node `Normalize Order`.

### Node 2: Code `Normalize Order`

- Mode: Run Once for Each Item
- Dán `snippets/normalize-new-order.js`.
- Giữ lại binary `idFront`, `idBack`, `bankProof`.

### Node 3–6: Đọc dữ liệu hiện có

Thêm các node Google Sheets/HTTP Request sau, đặt tên chính xác để các snippet gọi được:

- `Read All Time`: đọc toàn bộ tab `Đối tác all time`.
- `Read Phat Sinh`: đọc toàn bộ tab `Đại lý Phát sinh`.
- `Read Commission History`: đọc tab `Lịch sử chứng từ` (có cả cột `Mã hoa hồng` mới).
- `Read Next Code`: HTTP Request dùng Google Sheets OAuth2 credential, lấy đúng ô `X2` của tab `Đại lý Phát sinh`.

Với node `Read Next Code`:

- Method: GET
- URL (dùng expression, giữ nguyên Spreadsheet ID):

  ```js
  {{ 'https://sheets.googleapis.com/v4/spreadsheets/115wok3QehyifvVRtCi7a8Oz4D5r3dTu9OWpiwb_-O30/values/' + encodeURIComponent("'Đại lý Phát sinh'!X2") }}
  ```

- Authentication: Predefined Credential Type → Google Sheets OAuth2 API (chọn credential đang dùng để đọc sheet).
- Response expected: `{ "values": [["DL1234"]] }` hoặc giá trị mã tiếp theo theo định dạng thực tế trong sheet. Nếu X2 chỉ trả số mà mã đại lý cần tiền tố `DL`, hãy sửa rule ghép mã trong snippet — không đoán format khi chưa kiểm tra ô X2.

Các node đọc sheet cần chạy trước Code node `Resolve Agent & Duplicates`. Có thể nối tuần tự; snippet tham chiếu output theo node name.

### Node 7: Code `Resolve Agent & Duplicates`

- Mode: Run Once for All Items
- Dán `snippets/resolve-agent-and-duplicates.js`.
- Sửa lại aliases theo header thật.
- Node này kiểm tra mã hoa hồng đã tồn tại (chống gửi lặp khi timeout), đối chiếu CCCD, xác định mã hiện có hoặc mã mới từ X2, kiểm tra chủ tài khoản.
- Kết quả có `allowed: true/false`, `agentCode`, `agent` và `isNewAgent`.

### Node 8: IF `Allowed?`

- Điều kiện: `={{ $json.allowed === true }}`.
- Nhánh false → Respond to Webhook với HTTP 409 và body `={{ { ok: false, error: $json.error } }}`.
- Nhánh true → tiếp tục.

### Node 9: IF `Agent needs roster row?`

Dùng `alreadyActive` và `mode` từ output resolve:

- Nếu đã có trong `Đại lý Phát sinh`, bỏ qua bước append đại lý.
- Nếu có trong `Đối tác all time` nhưng chưa có trong `Đại lý Phát sinh`, **thêm một row ở `Đại lý Phát sinh` với mã cũ**; không cấp mã mới.
- Nếu là đại lý mới, lấy `agentCode` bằng kết quả đọc X2 rồi append một row trong `Đại lý Phát sinh`, cột A/Mã ĐL đúng theo cấu trúc sheet hiện tại.

Trong `Google Sheets → Append Row`, chỉ map cột nhập tay: mã, họ tên, CCCD, ngày sinh, quê quán, thường trú, ngân hàng, STK, chủ tài khoản, BD đại diện, trạng thái hồ sơ (theo header thực tế). Không ghi vào ô X2; không append thủ công vào vùng tự động của `Đối tác all time`.

**Đối chiếu trùng:** sau khi append đại lý mới, đọc lại dòng đó và kiểm tra cột W `Đối chiếu All time`. Nếu có cảnh báo trùng, dừng workflow, không tạo lệnh chi và báo CS/người quản lý. Hướng dẫn gốc yêu cầu xử lý dòng vừa nhập rồi dùng mã cũ; không bật thao tác Delete tự động nếu chưa chắc row number vì xóa nhầm dòng khác là rủi ro dữ liệu.

> Nếu hai lệnh mới có thể chạy gần như đồng thời, bật giới hạn concurrency thấp nhất có thể cho workflow này. Đặc biệt không để hai lần đọc X2/cấp mã cùng chạy đồng thời.

### Node 10: Tạo folder CCCD và lưu ảnh

Cấu hình Google Drive nodes dùng folder gốc **đã tạo sẵn** `2. CCCD đại lý`:

1. Nếu đại lý chưa có URL folder CCCD, Search files/folders theo tên `{{ $json.agentCode }} - {{ $json.agent.name }}` trong đúng parent folder.
2. Nếu tìm thấy folder, dùng folder đó. Nếu chưa có, Create Folder và lưu webViewLink/ID.
3. Upload binary `idFront` vào folder, tên file `{{ $json.agentCode }}_CCCD_truoc.jpg`.
4. Upload binary `idBack` vào folder, tên file `{{ $json.agentCode }}_CCCD_sau.jpg`.
5. Nếu có `bankProof`, có thể upload vào cùng folder với tên `{{ $json.agentCode }}_STK.jpg`.
6. Cập nhật link folder và checkbox “Đã lưu CCCD” theo cột thật ở tab `Đại lý Phát sinh`.

Nếu node Google Sheets làm mất binary, dùng một nhánh từ `Normalize Order` và `Merge` (Combine by Position) với metadata sau khi xác định mã đại lý trước khi chạy Google Drive Upload. Mở output từng node và chắc chắn binary `idFront`/`idBack` còn tồn tại.

Với đại lý hiện có, nếu hồ sơ yêu cầu thu CCCD lần đầu mà không có ảnh trong form, không đánh dấu đã lưu CCCD. Dừng để bổ sung ảnh/hoàn thiện hồ sơ trước khi cho phép chi.

### Node 11: Tạo folder chứng từ theo tháng/ngày

Trong folder gốc `3. Chứng từ chuyển khoản`:

1. Dùng payment date `YYYY-MM-DD` để xác định tháng.
2. Search folder tháng; nếu chưa có, tạo folder tháng theo quy ước kế toán đang sử dụng.
3. Trong đó search folder ngày; nếu chưa có, tạo folder ngày.
4. Ghi URL folder ngày vào cột `Link folder CK` của dòng lịch sử.

Nên chọn rõ một quy ước tên folder trước khi chạy thật, ví dụ `2026-10` / `2026-10-16`, để tránh tạo hai folder cho cùng tháng/ngày. Tại thời điểm tạo lệnh chưa có biên lai chuyển khoản; khi kế toán xác nhận `Đã chuyển`, nhắc họ upload ảnh/PDF biên lai vào folder ngày và đánh dấu `Đã lưu CK` trên sheet. Bản Mini App này chưa tự tải biên lai chuyển khoản sau khi chi; đây có thể là bước mở rộng tiếp theo.

### Node 12: Append Row `Lịch sử chứng từ`

Thực hiện **sau khi** resolve đại lý và tạo folder thành công. Mỗi lệnh đúng một dòng. Chỉ điền các trường người dùng nhập và system columns mới, ví dụ:

- Ngày thanh toán ← `paymentDate`
- Mã ĐL ← `agentCode`
- Số khách ← `guestCount` (nếu chưa xác nhận, dùng quy tắc ghi chú hiện tại của sheet; không tự bịa số khách)
- Số tiền ← `amount`
- Mã hoa hồng ← `commissionId`
- Trạng thái chi ← `Chờ chi`
- Ngày tạo lệnh ← `submittedAt`
- Telegram ID người tạo ← `telegramUserId`
- Người tạo ← `telegramName`
- Link folder CCCD ← URL folder CCCD
- Link folder CK ← URL folder ngày
- Ghi chú ← `note` hoặc `Cần bổ sung` nếu số khách chưa xác nhận

Tên đại lý/CCCD/ngân hàng/STK/STT/tên file chứng từ có thể tự tính dựa vào mã đại lý. Không ghi đè những cột đó nếu đang dùng công thức trong spreadsheet.

### Node 13: Telegram `Send Message` vào group

Sử dụng Telegram credential của bot. Chat ID là ID group kế toán, gồm dấu âm nếu có. Tin nhắn cần có ít nhất:

```text
🧾 LỆNH HOA HỒNG MỚI
Ngày: {{paymentDate}}
Mã hoa hồng: {{commissionId}}
Mã đại lý: {{agentCode}}
Tên đại lý: {{agent.name}}
Số khách: {{guestCount hoặc “Cần bổ sung”}}
Số tiền: {{amount định dạng VND}}
Ngân hàng: {{agent.bankName}}
STK: {{agent.accountNumber}}
Chủ TK: {{agent.accountHolder}}
Trạng thái: Chờ chi
Người tạo: {{telegramName}}
Folder chứng từ: {{folder ngày URL}}
```

Cấu hình **Reply Markup → Inline Keyboard** (nếu phiên bản node hỗ trợ) gồm các nút:

- `✅ Duyệt chi` → callback data `approve|{{commissionId}}`
- `❌ Từ chối` → callback data `reject|{{commissionId}}`
- `💸 Đã chuyển tiền` → callback data `paid|{{commissionId}}`

Nếu dùng Telegram node, callback data phải đặt đúng trường callback_data (không phải URL button). Nếu phiên bản n8n của bạn không hiện Inline Keyboard, dùng HTTP Request tới Telegram Bot API `sendMessage` với JSON `reply_markup.inline_keyboard`.

### Node 14: Respond to Webhook

Khi Google Sheets/Drive đã xử lý và tin nhắn group đã gửi thành công, trả status 200 JSON:

```json
{ "ok": true, "commissionId": "HH-20261016-ABC123", "status": "Chờ chi", "message": "Đã lưu và gửi kế toán" }
```

Đặt `Respond to Webhook` sau bước gửi Telegram. Nếu có lỗi, dùng Error branch / Error Trigger để báo quản lý. Sau timeout từ Vercel, luôn kiểm tra `Mã hoa hồng` trên sheet trước khi retry.

## D. Workflow 3 — `Commission - Telegram Callback Router`

**Chỉ tạo một Telegram Trigger workflow đang active cho bot này.** Telegram Bot API dùng webhook cho updates; nhiều Telegram Trigger workflow cùng bot có thể giành webhook của nhau. Các workflow khác có thể gửi tin bằng Telegram node nhưng không tạo trigger riêng cho cùng bot.

### Node 1: Telegram Trigger

- Credential: cùng bot đã tạo
- Update/Event: `Callback Query`
- Activate workflow.

### Node 2: Code `Parse & Authorize Callback`

- Mode: Run Once for All Items
- Dán `snippets/telegram-callback-router.js`.
- Thay `FINANCE_USER_IDS` bằng numeric Telegram ID của đúng kế toán được quyền duyệt. Danh sách CS không tự động có quyền duyệt.

### Node 3: IF `Authorized + valid?`

Điều kiện `={{ $json.valid === true && $json.authorized === true }}`.

- Nhánh false: trả lời callback “Bạn không có quyền thực hiện thao tác này” bằng Telegram Answer Callback Query; không cập nhật sheet.
- Nhánh true: đọc tab `Lịch sử chứng từ`, tìm **đúng một** row theo `Mã hoa hồng`.

### Node 4: Code `Validate Status Transition`

- Mode: Run Once for All Items
- Dán `snippets/validate-status-transition.js`; đặt tên node trước đó đúng là `Parse & Authorize Callback` và node đọc sheet đúng là `Find Commission`.
- Chỉnh aliases `STATUS_ALIASES` và `ID_ALIASES` theo hàng tiêu đề thật.

Sau đó thêm IF theo `={{ $json.canUpdate === true }}`. Nhánh false chỉ trả lời callback và không sửa sheet. Nhánh true cập nhật row:

- `approve`: chỉ được phép khi trạng thái hiện tại `Chờ chi` → đổi thành `Đã duyệt`, ghi `Người duyệt`, `Thời điểm duyệt`.
- `reject`: chỉ được phép khi trạng thái là `Chờ chi` → đổi thành `Từ chối`, ghi người và thời điểm; có thể yêu cầu ghi lý do vào Ghi chú.
- `paid`: chỉ được phép khi trạng thái là `Đã duyệt` → đổi thành `Đã chuyển`, ghi `Người chuyển`, `Thời điểm chuyển`.
- Các trường hợp click lặp, ID không tìm thấy hoặc trạng thái không hợp lệ: trả lời callback và **không** sửa sheet.

Update đúng row đã tìm thấy theo `Mã hoa hồng`, không tìm bằng tên đại lý hay bằng số tiền. Sau khi cập nhật, dùng Telegram Edit Message / Edit Reply Markup để bỏ các nút cũ và cập nhật tin nhắn theo trạng thái mới. Tránh để một nút cũ bấm được nhiều lần.

**Quan trọng:** nút `Đã chuyển tiền` chỉ ghi nhận việc kế toán đã chuyển khoản thật ở ngân hàng. Workflow này không tự thực hiện giao dịch ngân hàng.

## E. Test trước khi dùng thật

1. Một lệnh với đại lý cũ có đủ CCCD/ngân hàng/STK: chỉ có 1 row lịch sử, trạng thái `Chờ chi`, bot gửi 1 tin group.
2. Một đại lý mới với CCCD chưa tồn tại: cấp mã theo X2, ghi row `Đại lý Phát sinh`, lưu hai ảnh CCCD đúng tên, tạo folder ngày và một row lịch sử.
3. Một đại lý mới với CCCD đã tồn tại: phải từ chối tạo mới và chỉ rõ mã hiện có; không tạo lệnh hoặc folder thừa.
4. Một agent trong all-time nhưng chưa ở tab phát sinh: thêm đúng mã cũ vào tab phát sinh, không cấp mã mới.
5. Bấm Duyệt với tài khoản không thuộc `FINANCE_USER_IDS`: không được đổi trạng thái.
6. Bấm `Đã chuyển tiền` khi chưa `Đã duyệt`: workflow từ chối.
7. Retry cùng một `commissionId`: không append duplicate row.
8. Sau một khoản chi thử, lưu ảnh/PDF biên lai vào folder ngày và tick `Đã lưu CK` đúng trên sheet.
