/**
 * n8n Code node: Run Once for All Items.
 * REQUIRED preceding nodes, named exactly:
 *   Normalize Order
 *   Read All Time
 *   Read Phat Sinh
 *   Read Commission History
 *   Read Next Code     (HTTP Request to Google Sheets API reading `'Đại lý Phát sinh'!X2`)
 *
 * This node prepares/guards data. It does NOT write any sheet or transfer money.
 * Adjust FIELD aliases to your actual header row before activating.
 */
const inputItem = $('Normalize Order').first();
const req = inputItem.json;
const allTime = $('Read All Time').all().map(x => x.json);
const active = $('Read Phat Sinh').all().map(x => x.json);
const history = $('Read Commission History').all().map(x => x.json);
const nextCodePayload = $('Read Next Code').first().json;
const nextRaw = nextCodePayload?.values?.[0]?.[0] ?? nextCodePayload?.nextCode ?? '';

const FIELD = {
  code: ['Mã ĐL', 'Mã đại lý', 'Ma DL', 'Code', 'Mã DL'],
  name: ['Họ tên', 'Tên đại lý', 'Họ và tên', 'Tên đối tác', 'Full name'],
  cccd: ['CCCD', 'Số CCCD', 'Số căn cước', 'CCCD/CMND'],
  bankName: ['Ngân hàng', 'Tên ngân hàng', 'Bank'],
  accountNumber: ['STK', 'Số tài khoản', 'Số TK', 'Account number'],
  accountHolder: ['Chủ TK', 'Tên chủ tài khoản', 'Chủ tài khoản', 'Account holder'],
  dob: ['Ngày sinh', 'Ngày tháng năm sinh', 'DOB'],
  hometown: ['Quê quán', 'Quê quán (CCCD)'],
  residence: ['Nơi thường trú', 'Địa chỉ thường trú', 'Thường trú'],
  bdRepresentative: ['BD đại diện', 'BD phụ trách', 'Nhân sự BD'],
  compareAllTime: ['Đối chiếu All time', 'Đối chiếu All Time'],
  commissionId: ['Mã hoa hồng', 'Mã lệnh hoa hồng', 'Commission ID'],
};
function get(row, aliases) {
  for (const k of aliases) if (row[k] !== undefined && row[k] !== null && String(row[k]).trim() !== '') return String(row[k]).trim();
  return '';
}
function byCode(rows, code) { return rows.find(row => get(row, FIELD.code) === code); }
function normId(v) { return String(v ?? '').replace(/\D/g, ''); }
function normName(v) { return String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/gi, 'd').replace(/\s+/g, ' ').trim().toLowerCase(); }
function result(extra) {
  return [{ json: { ...req, ...extra }, binary: inputItem.binary ?? {} }];
}

// Prevent retries/timeouts from appending the same commission twice.
const duplicateCommission = history.find(row => get(row, FIELD.commissionId) === req.commissionId);
if (duplicateCommission) return result({ allowed: false, error: `Mã hoa hồng ${req.commissionId} đã tồn tại. Không ghi thêm dòng lần nữa.` });

if (req.mode === 'existing') {
  const mainRow = byCode(allTime, req.agentCode);
  const activeRow = byCode(active, req.agentCode);
  if (!mainRow && !activeRow) return result({ allowed: false, error: `Không tìm thấy mã đại lý ${req.agentCode}. Hãy tải lại danh sách đại lý.` });
  const merged = { ...(mainRow ?? {}), ...(activeRow ?? {}) };
  const agent = {
    code: req.agentCode,
    name: get(merged, FIELD.name) || req.fullName,
    cccd: get(merged, FIELD.cccd) || req.cccd,
    bankName: get(merged, FIELD.bankName) || req.bankName,
    accountNumber: get(merged, FIELD.accountNumber) || req.accountNumber,
    accountHolder: get(merged, FIELD.accountHolder) || req.accountHolder,
    dob: get(merged, FIELD.dob) || req.dob,
    hometown: get(merged, FIELD.hometown) || req.hometown,
    residence: get(merged, FIELD.residence) || req.residence,
    bdRepresentative: get(merged, FIELD.bdRepresentative) || req.bdRepresentative,
    compareAllTime: get(merged, FIELD.compareAllTime),
  };
  if (!agent.name || !agent.cccd || !agent.bankName || !agent.accountNumber || !agent.accountHolder) {
    return result({ allowed: false, error: `Hồ sơ ${req.agentCode} thiếu họ tên/CCCD/ngân hàng/STK/chủ TK. Cập nhật tab “Đại lý Phát sinh” trước khi tạo lệnh.` });
  }
  if (normName(agent.accountHolder) !== normName(agent.name)) {
    return result({ allowed: false, error: `Chủ tài khoản của ${req.agentCode} không khớp tên đại lý. Cần kiểm tra thủ công trước khi chi.` });
  }
  return result({ allowed: true, agent, agentCode: agent.code, alreadyActive: Boolean(activeRow), duplicateCCCD: false });
}

if (req.mode === 'new') {
  const normalizedCCCD = normId(req.cccd);
  const existing = [...allTime, ...active].find(row => normId(get(row, FIELD.cccd)) === normalizedCCCD && normalizedCCCD);
  if (existing) {
    const existingCode = get(existing, FIELD.code);
    return result({ allowed: false, duplicateCCCD: true, existingCode, error: `CCCD đã có trong sheet theo mã ${existingCode || '(không đọc được mã)'}. Không tạo dòng mới; hãy chọn đúng mã đại lý hiện có.` });
  }
  const proposedCode = String(nextRaw).trim();
  if (!proposedCode) return result({ allowed: false, error: 'Không đọc được mã tiếp theo ở ô X2 của “Đại lý Phát sinh”. Dừng để kiểm tra sheet.' });
  const idCollision = allTime.some(row => get(row, FIELD.code) === proposedCode) || active.some(row => get(row, FIELD.code) === proposedCode);
  if (idCollision) return result({ allowed: false, error: `Mã ở X2 (${proposedCode}) đã có trong sheet. Không ghi đè; hãy kiểm tra công thức cấp mã.` });
  if (normName(req.accountHolder) !== normName(req.fullName)) {
    return result({ allowed: false, error: 'Chủ tài khoản không trùng họ tên CCCD.' });
  }
  const compareCandidate = {
    code: proposedCode,
    name: req.fullName,
    cccd: req.cccd,
    bankName: req.bankName,
    accountNumber: req.accountNumber,
    accountHolder: req.accountHolder,
    dob: req.dob,
    hometown: req.hometown,
    residence: req.residence,
    bdRepresentative: req.bdRepresentative,
  };
  return result({ allowed: true, agent: compareCandidate, agentCode: proposedCode, alreadyActive: false, duplicateCCCD: false, isNewAgent: true });
}

return result({ allowed: false, error: 'Loại đại lý không hợp lệ.' });
