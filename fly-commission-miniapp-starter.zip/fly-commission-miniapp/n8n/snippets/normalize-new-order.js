/**
 * n8n Code node after Webhook (Form-Data) named "Receive Commission Order".
 * Run Once for Each Item. Check the actual webhook test output once, because n8n versions
 * may place text fields in $json.body and uploaded images in $binary.
 * This node keeps binary properties so downstream Google Drive Upload nodes can use them.
 */
const item = $input.item;
const body = item.json?.body ?? item.json ?? {};
const pick = (key) => body[key] === undefined || body[key] === null ? '' : String(body[key]).trim();

const out = {
  source: pick('source'),
  mode: pick('mode'),
  commissionId: pick('commissionId'),
  status: 'Chờ chi',
  agentCode: pick('agentCode'),
  paymentDate: pick('paymentDate'),
  guestCount: pick('guestCount'),
  countUnconfirmed: pick('countUnconfirmed') === 'true',
  amount: Number(pick('amount')),
  fullName: pick('fullName'),
  cccd: pick('cccd').replace(/\s+/g, ''),
  dob: pick('dob'),
  hometown: pick('hometown'),
  residence: pick('residence'),
  bankName: pick('bankName'),
  accountNumber: pick('accountNumber').replace(/[\s-]/g, ''),
  accountHolder: pick('accountHolder'),
  bdRepresentative: pick('bdRepresentative'),
  note: pick('note'),
  submittedAt: pick('submittedAt'),
  telegramUserId: pick('telegramUserId'),
  telegramName: pick('telegramName'),
  telegramUsername: pick('telegramUsername'),
};

if (!/^HH-\d{8}-[A-F0-9]{6}$/.test(out.commissionId)) throw new Error('Mã hoa hồng không hợp lệ.');
if (!/^\d{4}-\d{2}-\d{2}$/.test(out.paymentDate)) throw new Error('Ngày thanh toán không hợp lệ.');
if (!Number.isFinite(out.amount) || out.amount <= 0) throw new Error('Số tiền hoa hồng không hợp lệ.');
if (!['existing', 'new'].includes(out.mode)) throw new Error('Loại đại lý không hợp lệ.');
if (out.mode === 'existing' && !out.agentCode) throw new Error('Thiếu mã đại lý.');
if (out.mode === 'new' && (!out.fullName || !/^\d{12}$/.test(out.cccd))) throw new Error('Thiếu tên hoặc CCCD đại lý mới.');

return { json: out, binary: item.binary ?? {} };
