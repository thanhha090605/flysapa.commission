/**
 * n8n Code node after:
 *   - Parse & Authorize Callback (snippet telegram-callback-router.js)
 *   - Find Commission (Google Sheets read rows filtered by Mã hoa hồng)
 *
 * Configure Code node to Run Once for All Items. Ensure Find Commission returns exactly one row.
 * Update the aliases below to match your exact history-sheet headers.
 */
const callback = $('Parse & Authorize Callback').first().json;
const matches = $('Find Commission').all().map(x => x.json);
const STATUS_ALIASES = ['Trạng thái chi', 'Status', 'Trạng thái'];
const ID_ALIASES = ['Mã hoa hồng', 'Mã lệnh hoa hồng', 'Commission ID'];
function get(row, aliases) {
  for (const key of aliases) if (row[key] !== undefined && row[key] !== null && String(row[key]).trim() !== '') return String(row[key]).trim();
  return '';
}
if (!callback.valid || !callback.authorized) {
  return [{ json: { ...callback, canUpdate: false, error: callback.reason || 'Unauthorized callback' } }];
}
const rowMatches = matches.filter(row => get(row, ID_ALIASES) === callback.commissionId);
if (rowMatches.length !== 1) {
  return [{ json: { ...callback, canUpdate: false, error: rowMatches.length === 0 ? 'Không tìm thấy mã hoa hồng.' : 'Có nhiều dòng trùng mã hoa hồng; dừng để kiểm tra dữ liệu.' } }];
}
const row = rowMatches[0];
const currentStatus = get(row, STATUS_ALIASES);
let nextStatus = '';
if (callback.action === 'approve' && currentStatus === 'Chờ chi') nextStatus = 'Đã duyệt';
if (callback.action === 'reject' && currentStatus === 'Chờ chi') nextStatus = 'Từ chối';
if (callback.action === 'paid' && currentStatus === 'Đã duyệt') nextStatus = 'Đã chuyển';
if (!nextStatus) {
  return [{ json: { ...callback, canUpdate: false, currentStatus, error: `Không thể thực hiện ${callback.action} khi trạng thái hiện tại là “${currentStatus || 'trống'}”.` } }];
}
return [{
  json: {
    ...callback,
    canUpdate: true,
    currentStatus,
    nextStatus,
    row,
    changedAt: new Date().toISOString(),
    auditName: callback.telegramName || String(callback.telegramUserId),
  }
}];
