/**
 * n8n Code node immediately after the ONE active Telegram Trigger for callback_query updates.
 * Replace numeric IDs with your accountants' Telegram user IDs. Never authorize by @username.
 * Configure the trigger to receive Callback Query updates; route authorized actions downstream.
 */
const FINANCE_USER_IDS = [111111111, 222222222]; // TODO: replace with accountant Telegram numeric IDs
const q = $input.first().json.callback_query;
if (!q?.id || !q?.from?.id || !q?.data) {
  return [{ json: { valid: false, authorized: false, reason: 'Missing callback query' } }];
}
const [action, commissionId] = String(q.data).split('|');
const allowedActions = new Set(['approve', 'reject', 'paid']);
const authorized = FINANCE_USER_IDS.includes(Number(q.from.id));
const idLooksValid = /^HH-\d{8}-[A-F0-9]{6}$/.test(commissionId ?? '');
return [{
  json: {
    valid: Boolean(allowedActions.has(action) && idLooksValid),
    authorized,
    action,
    commissionId,
    callbackQueryId: q.id,
    telegramUserId: Number(q.from.id),
    telegramName: [q.from.first_name, q.from.last_name].filter(Boolean).join(' '),
    chatId: q.message?.chat?.id,
    messageId: q.message?.message_id,
    reason: !authorized ? 'Không có quyền kế toán' : !idLooksValid ? 'Mã hoa hồng không hợp lệ' : '',
  }
}];
