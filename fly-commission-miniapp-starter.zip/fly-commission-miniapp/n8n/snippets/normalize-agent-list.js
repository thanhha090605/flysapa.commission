/**
 * n8n Code node: Run Once for All Items.
 * Create two Google Sheets nodes named exactly:
 *   1) Read All Time  -> tab "Đối tác all time"
 *   2) Read Phat Sinh -> tab "Đại lý Phát sinh"
 *
 * IMPORTANT: after viewing your header rows, edit FIELD ALIASES below to match exact column names.
 * Return only agents needed by authorized CS users; do not include CCCD images/bank evidence here.
 */
const allTime = $('Read All Time').all().map(x => x.json);
const active = $('Read Phat Sinh').all().map(x => x.json);

const FIELD = {
  code: ['Mã ĐL', 'Mã đại lý', 'Ma DL', 'Code', 'Mã DL'],
  name: ['Họ tên', 'Tên đại lý', 'Họ và tên', 'Tên đối tác', 'Full name'],
  cccd: ['CCCD', 'Số CCCD', 'Số căn cước', 'CCCD/CMND'],
  bankName: ['Ngân hàng', 'Tên ngân hàng', 'Bank'],
  accountNumber: ['STK', 'Số tài khoản', 'Số TK', 'Account number'],
  accountHolder: ['Chủ TK', 'Tên chủ tài khoản', 'Chủ tài khoản', 'Account holder'],
  dob: ['Ngày sinh', 'Ngày tháng năm sinh', 'DOB'],
  hometown: ['Quê quán', 'Quê quán (CCCD)'],
  residence: ['Nơi thường trú', 'Địa chỉ thường trú', 'Thường trú'],
  bdRepresentative: ['BD đại diện', 'BD phụ trách', 'Nhân sự BD'],
  idFolderUrl: ['Folder CCCD', 'Thư mục CCCD', 'Link folder CCCD'],
};

function get(row, aliases) {
  for (const key of aliases) {
    if (row[key] !== undefined && row[key] !== null && String(row[key]).trim() !== '') return String(row[key]).trim();
  }
  return '';
}

// Start with All Time for the full list, then let active-sheet fields override missing/stale values.
const byCode = new Map();
for (const row of allTime) {
  const code = get(row, FIELD.code);
  const name = get(row, FIELD.name);
  if (!code || !name) continue;
  byCode.set(code, {
    code, name,
    cccd: get(row, FIELD.cccd),
    bankName: get(row, FIELD.bankName),
    accountNumber: get(row, FIELD.accountNumber),
    accountHolder: get(row, FIELD.accountHolder),
    dob: get(row, FIELD.dob),
    hometown: get(row, FIELD.hometown),
    residence: get(row, FIELD.residence),
    bdRepresentative: get(row, FIELD.bdRepresentative),
    idFolderUrl: get(row, FIELD.idFolderUrl),
  });
}
for (const row of active) {
  const code = get(row, FIELD.code);
  const name = get(row, FIELD.name);
  if (!code || !name) continue;
  const old = byCode.get(code) || { code, name };
  byCode.set(code, {
    ...old,
    name: name || old.name,
    cccd: get(row, FIELD.cccd) || old.cccd || '',
    bankName: get(row, FIELD.bankName) || old.bankName || '',
    accountNumber: get(row, FIELD.accountNumber) || old.accountNumber || '',
    accountHolder: get(row, FIELD.accountHolder) || old.accountHolder || '',
    dob: get(row, FIELD.dob) || old.dob || '',
    hometown: get(row, FIELD.hometown) || old.hometown || '',
    residence: get(row, FIELD.residence) || old.residence || '',
    bdRepresentative: get(row, FIELD.bdRepresentative) || old.bdRepresentative || '',
    idFolderUrl: get(row, FIELD.idFolderUrl) || old.idFolderUrl || '',
  });
}

const agents = [...byCode.values()].sort((a, b) => a.code.localeCompare(b.code, 'vi', { numeric: true }));
return [{ json: { agents } }];
