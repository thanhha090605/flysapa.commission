export type OcrCandidates = {
  fullName: string;
  cccd: string;
  dob: string;
  hometown: string;
  residence: string;
  bankName: string;
  accountNumber: string;
  accountHolder: string;
};

const BANKS: Array<{ canonical: string; aliases: string[] }> = [
  { canonical: 'Vietcombank', aliases: ['vietcombank', 'vcb', 'ngan hang ngoai thuong'] },
  { canonical: 'BIDV', aliases: ['bidv', 'dau tu va phat trien'] },
  { canonical: 'VietinBank', aliases: ['vietinbank', 'ctg', 'cong thuong viet nam'] },
  { canonical: 'Techcombank', aliases: ['techcombank', 'tcb'] },
  { canonical: 'MB Bank', aliases: ['mb bank', 'mbbank', 'quan doi'] },
  { canonical: 'ACB', aliases: ['acb', 'a chau'] },
  { canonical: 'VPBank', aliases: ['vpbank', 'vpb'] },
  { canonical: 'TPBank', aliases: ['tpbank', 'tien phong'] },
  { canonical: 'Sacombank', aliases: ['sacombank', 'stb'] },
  { canonical: 'Agribank', aliases: ['agribank', 'nong nghiep va phat trien nong thon'] },
  { canonical: 'HDBank', aliases: ['hdbank', 'hd bank'] },
  { canonical: 'VIB', aliases: ['vib', 'quoc te'] },
  { canonical: 'OCB', aliases: ['ocb', 'phuong dong'] },
  { canonical: 'MSB', aliases: ['msb', 'hang hai'] },
  { canonical: 'SHB', aliases: ['shb', 'sai gon ha noi'] },
  { canonical: 'SeABank', aliases: ['seabank', 'dong nam a'] },
  { canonical: 'LPBank', aliases: ['lpbank', 'lien viet'] },
  { canonical: 'Eximbank', aliases: ['eximbank', 'xuat nhap khau'] },
  { canonical: 'PVcomBank', aliases: ['pvcombank'] },
  { canonical: 'Bac A Bank', aliases: ['bac a bank', 'baca bank'] },
  { canonical: 'SHINHAN Bank', aliases: ['shinhan bank', 'shinhan'] },
];

function asciiFold(value: string): string {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase();
}

function valueFollowingLabel(text: string, labels: RegExp): string {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!labels.test(asciiFold(line))) continue;
    const inline = line.replace(/^.*?(?:[:：]|\s{2,})/, '').trim();
    if (inline && !labels.test(asciiFold(inline))) return inline.replace(/^[|:：\-\s]+/, '').trim();
    const next = lines[i + 1];
    if (next && !/^(ho va ten|full name|ngay sinh|date of birth|so|no|que quan|noi thuong tru|place of residence)/i.test(asciiFold(next))) {
      return next.trim();
    }
  }
  return '';
}

export function parseOcrCandidates(text: string, documentType: 'identity' | 'bank'): OcrCandidates {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const folded = asciiFold(text);
  let cccd = '';
  if (documentType === 'identity') {
    const direct = text.match(/\b\d{12}\b/);
    if (direct) cccd = direct[0];
    if (!cccd) {
      for (const line of lines) {
        const digits = line.replace(/[^0-9]/g, '');
        if (digits.length === 12) { cccd = digits; break; }
      }
    }
  }

  const dateMatch = text.match(/\b(0?[1-9]|[12]\d|3[01])[./-](0?[1-9]|1[0-2])[./-]((?:19|20)\d{2})\b/);
  const bank = BANKS.find(({ aliases }) => aliases.some((alias) => folded.includes(alias)));
  let accountNumber = '';
  if (documentType === 'bank') {
    const taggedLine = lines.find((line) => /so tai khoan|account number|stk\b/i.test(asciiFold(line)));
    const candidateFromLine = taggedLine?.match(/(?:\d[ -]?){6,20}/)?.[0].replace(/\D/g, '') ?? '';
    if (candidateFromLine.length >= 6 && candidateFromLine.length <= 20) accountNumber = candidateFromLine;
    if (!accountNumber) {
      const candidates = text.match(/\b\d{8,19}\b/g) ?? [];
      accountNumber = candidates.find((candidate) => candidate.length !== 12 && !/^(19|20)\d{6}$/.test(candidate)) ?? '';
    }
  }

  const fullName = valueFollowingLabel(text, /ho va ten|full name|ten khach hang|account holder|chu tai khoan/);
  const accountHolder = valueFollowingLabel(text, /chu tai khoan|account holder|account name|ten chu tai khoan/);
  const hometown = valueFollowingLabel(text, /que quan|place of origin/);
  const residence = valueFollowingLabel(text, /noi thuong tru|place of residence|thuong tru/);

  return {
    fullName: documentType === 'identity' ? fullName : '',
    cccd,
    dob: dateMatch ? `${dateMatch[1].padStart(2, '0')}/${dateMatch[2].padStart(2, '0')}/${dateMatch[3]}` : '',
    hometown: documentType === 'identity' ? hometown : '',
    residence: documentType === 'identity' ? residence : '',
    bankName: documentType === 'bank' ? (bank?.canonical ?? '') : '',
    accountNumber,
    accountHolder: documentType === 'bank' ? accountHolder : '',
  };
}
