import crypto from 'node:crypto';

export type TelegramMiniAppUser = {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  language_code?: string;
};

export type VerifiedTelegramUser = {
  user: TelegramMiniAppUser;
  authDate: number;
};

/** Verify Telegram Mini App initData on the server, never trust initDataUnsafe. */
export function verifyTelegramInitData(initData: string): VerifiedTelegramUser | null {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken || !initData || initData.length > 10_000) return null;

  try {
    const params = new URLSearchParams(initData);
    const receivedHash = params.get('hash');
    const authDateRaw = params.get('auth_date');
    const userRaw = params.get('user');
    if (!receivedHash || !authDateRaw || !userRaw) return null;

    const pairs: string[] = [];
    for (const [key, value] of params.entries()) {
      // Exclude only the supplied HMAC hash; preserve every other initData field, including signature if present.
      if (key === 'hash') continue;
      pairs.push(`${key}=${value}`);
    }
    pairs.sort((a, b) => a.localeCompare(b));
    const dataCheckString = pairs.join('\n');

    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
    const expectedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
    const expected = Buffer.from(expectedHash, 'hex');
    const actual = Buffer.from(receivedHash, 'hex');
    if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) return null;

    const authDate = Number(authDateRaw);
    const nowSeconds = Math.floor(Date.now() / 1000);
    // Reject missing/future timestamps and data older than 24 hours.
    if (!Number.isFinite(authDate) || authDate > nowSeconds + 60 || nowSeconds - authDate > 24 * 60 * 60) return null;

    const user = JSON.parse(userRaw) as TelegramMiniAppUser;
    if (!user || !Number.isSafeInteger(user.id) || user.id <= 0) return null;
    return { user, authDate };
  } catch {
    return null;
  }
}

export function parseTelegramUserIdList(raw: string | undefined): Set<number> {
  return new Set(
    (raw ?? '')
      .split(',')
      .map((value) => Number(value.trim()))
      .filter((value) => Number.isSafeInteger(value) && value > 0),
  );
}

export function isAllowedTelegramUser(userId: number, envName = 'CS_TELEGRAM_IDS'): boolean {
  const allowed = parseTelegramUserIdList(process.env[envName]);
  return allowed.has(userId);
}
