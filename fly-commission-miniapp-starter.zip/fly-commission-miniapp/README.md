# Fly Sapa — Telegram Mini App tạo lệnh hoa hồng đại lý

Bản code nền cho Mini App chạy trên Vercel. Giao diện dùng Telegram `initData`; API server xác thực initData, gọi OCR.space ở phía server và chuyển form + ảnh sang n8n. n8n là nơi nối Google Sheets, Google Drive và Telegram group.

> **Chưa phải hệ thống có thể bấm deploy là chạy ngay.** Cần cấu hình credential, webhook và ánh xạ đúng tiêu đề cột Google Sheets theo sheet thật. Ảnh bạn cung cấp mới cho thấy tab `Hướng dẫn`, chưa thấy hàng tiêu đề của `Đối tác all time`, `Đại lý Phát sinh`, `Lịch sử chứng từ`. Hãy làm theo `n8n/README.md` trước khi dùng dữ liệu thật.

## Có sẵn trong code

- Form chọn đại lý có sẵn hoặc bấm `＋ Đại lý mới`.
- Đại lý có sẵn: chọn từ danh sách n8n trả về và hiển thị CCCD/ngân hàng/STK.
- Đại lý mới: nhập/cập nhật họ tên, CCCD, ngày sinh, quê quán, thường trú, BD đại diện, ngân hàng, STK, chủ tài khoản; yêu cầu ảnh CCCD hai mặt.
- Nút OCR.space cho CCCD mặt trước, mặt sau và ảnh tài khoản. OCR chỉ điền **gợi ý**, người nhập phải kiểm tra.
- Ngày thanh toán, số khách, tùy chọn “Chưa xác nhận số khách”, tiền hoa hồng và ghi chú.
- Mã hoa hồng sinh ở server theo dạng `HH-YYYYMMDD-XXXXXX`.
- Xác thực Telegram Mini App `initData` phía server và allowlist Telegram ID cho CS.
- API key OCR.space, bot token và n8n webhook secret chỉ đặt ở biến môi trường server.
- Snippet cho n8n lấy đại lý, chuẩn hóa order, và router nút duyệt của kế toán.

## Cấu trúc thư mục

```text
app/
  api/agents/route.ts     # lấy danh sách đại lý từ n8n
  api/ocr/route.ts        # gọi OCR.space
  api/submit/route.ts     # kiểm tra và chuyển form + ảnh tới n8n
  page.tsx                # Telegram Mini App UI
  globals.css
lib/
  telegram-auth.ts        # kiểm tra HMAC initData và allowlist
  ocr-parser.ts           # đề xuất trường từ nội dung OCR
n8n/
  README.md               # cách tạo các workflow n8n
  snippets/               # code cho các Code node
.env.example
```

## 1. Chuẩn bị Telegram

1. Mở `@BotFather` và tạo bot mới bằng `/newbot`; giữ bot token bí mật.
2. Tạo group nội bộ cho kế toán, thêm bot vào group và kiểm tra bot được gửi tin.
3. Lấy Telegram numeric user ID của từng CS và kế toán; dùng numeric ID, không dùng username làm quyền.
4. Deploy Mini App lên HTTPS trước. Sau đó cấu hình domain / menu button của bot trong `@BotFather` (Bot Settings → Menu Button) trỏ về URL Vercel.
5. Nên test trên Telegram mobile và Telegram Desktop. Không mở app trực tiếp từ một tab trình duyệt thông thường vì API từ chối khi thiếu `initData` thật.

## 2. Chạy local / đưa code lên GitHub

Cần Node.js 20 trở lên.

```bash
cp .env.example .env.local
npm install
npm run dev
```

Lưu ý: `initData` thật chỉ có khi mở qua Telegram, vì vậy `localhost` chưa thể gọi API thành công nếu chưa cấu hình Telegram Mini App và HTTPS tunnel/domain. Không bật chế độ bỏ qua xác thực trong môi trường thật.

Tạo repository GitHub, đưa toàn bộ thư mục này lên GitHub, sau đó trên Vercel chọn **Add New → Project → Import Git Repository**.

## 3. Biến môi trường trên Vercel

Điền các giá trị sau ở **Project → Settings → Environment Variables**, sau đó redeploy:

| Key | Dùng để làm gì |
|---|---|
| `TELEGRAM_BOT_TOKEN` | Xác thực Telegram `initData` ở server. |
| `OCR_SPACE_API_KEY` | API key OCR.space; không đặt tên `NEXT_PUBLIC_*`. |
| `N8N_AGENT_LIST_WEBHOOK` | URL production webhook GET lấy đại lý. |
| `N8N_COMMISSION_CREATE_WEBHOOK` | URL production webhook POST tạo lệnh. |
| `N8N_WEBHOOK_SECRET` | Secret dài, ngẫu nhiên; nhập giống hệt trong Header Auth credentials của n8n. |
| `CS_TELEGRAM_IDS` | Danh sách ID numeric của CS, ngăn người ngoài tạo lệnh. Ví dụ `123456789,234567890`. |
| `MAX_UPLOAD_TOTAL_BYTES` | Mặc định 3,800,000 byte để tránh request quá lớn. |
| `MAX_SINGLE_FILE_BYTES` | Mặc định 1,700,000 byte mỗi ảnh. |

Không bao giờ commit `.env.local`, bot token, OCR key, secret, ảnh CCCD hoặc dữ liệu tài khoản lên GitHub.

## 4. Định dạng dữ liệu API mà n8n phải trả về

### Webhook lấy danh sách đại lý

`GET /commission-agents` phải trả JSON dạng:

```json
{
  "agents": [
    {
      "code": "DL170",
      "name": "NGUYEN VAN A",
      "cccd": "012345678901",
      "bankName": "Vietcombank",
      "accountNumber": "0123456789",
      "accountHolder": "NGUYEN VAN A",
      "dob": "01/01/1990",
      "hometown": "...",
      "residence": "...",
      "bdRepresentative": "...",
      "idFolderUrl": "https://drive.google.com/..."
    }
  ]
}
```

Tệp `n8n/snippets/normalize-agent-list.js` gom `Đối tác all time` và `Đại lý Phát sinh`. Bạn phải sửa aliases trong `FIELD` khớp **chính xác** hàng tiêu đề đang có.

### Webhook tạo lệnh

`POST /commission-create` nhận multipart/form-data với trường text như `commissionId`, `mode`, `agentCode`, `paymentDate`, `amount`, `guestCount`, `status`, thông tin đại lý và các binary `idFront`, `idBack`, `bankProof` (có thể không có `bankProof`).

Khi thành công, trả JSON:

```json
{ "ok": true, "commissionId": "HH-20261016-ABC123", "status": "Chờ chi", "message": "Đã lưu và gửi kế toán" }
```

Khi thất bại, trả HTTP status 4xx/5xx và `{ "ok": false, "error": "Lý do cụ thể" }`. Nếu Vercel timeout mà không nhận phản hồi, hãy kiểm tra **n8n Executions và Google Sheet theo mã hoa hồng** trước khi bấm gửi lại, để tránh tạo trùng.

## 5. Quan trọng về OCR và ảnh

- API gọi `https://api.ocr.space/parse/image` ở server, gửi `language=vnm`, `OCREngine=2` và `isOverlayRequired=false`.
- OCR có thể nhận nhầm số CCCD, tên người, ngày sinh, ngân hàng hoặc STK. Phải cho CS xem và sửa trước khi gửi lệnh.
- Ảnh CCCD/tài khoản là dữ liệu cá nhân nhạy cảm. Cần quyền xử lý phù hợp, hạn chế quyền truy cập Google Drive, không đưa ảnh vào log công khai, và xem xét điều khoản lưu/xử lý của OCR.space trước khi chạy thật.
- Ảnh client được nén xuống JPEG để giảm dung lượng request Vercel. Nếu trình duyệt không đọc được HEIC, hãy chụp lại hoặc chuyển thành JPG.

## 6. Quy tắc nghiệp vụ không được bỏ qua

1. Chỉ cấp mã mới bằng giá trị trong ô X2 của tab `Đại lý Phát sinh`; không tự đánh số trên Mini App.
2. Kiểm tra CCCD/mã đại lý trong `Đối tác all time` và `Đại lý Phát sinh` **trước khi** thêm row mới.
3. Không ghi vào vùng công thức / vùng auto-generated của `Đối tác all time`.
4. Đối chiếu cột W `Đối chiếu All time` sau khi thêm đại lý mới. Nếu có cảnh báo trùng, dừng workflow và báo người phụ trách xử lý đúng dòng vừa tạo; không xóa row tự động khi chưa định danh chắc chắn row đó.
5. Thêm cột hệ thống vào cuối `Lịch sử chứng từ` nếu chưa có: `Mã hoa hồng`, `Trạng thái chi`, `Ngày tạo lệnh`, `Telegram ID người tạo`, `Người tạo`, `Người duyệt`, `Thời điểm duyệt`, `Người chuyển`, `Thời điểm chuyển`, `Link folder CCCD`, `Link folder CK`, `Ghi chú`. Không chèn vào giữa hoặc ghi đè cột công thức.
6. Trạng thái chi đi theo luồng `Chờ chi` → `Đã duyệt` → `Đã chuyển`, hoặc `Chờ chi` → `Từ chối`. `Đã chuyển` chỉ sau khi kế toán đã chuyển khoản thật.
7. Một lần tạo lệnh phải ghi đúng một dòng trong `Lịch sử chứng từ` và gửi tin vào group sau khi lưu Sheets thành công.

## Tình trạng triển khai

Đây là code Mini App và các snippet tích hợp; **workflow n8n chưa được kết nối trực tiếp vào spreadsheet của bạn** vì ảnh hiện có chưa thể hiện hàng tiêu đề và mapping cột dữ liệu. Hãy hoàn tất `n8n/README.md`, test với một đại lý thử và giá trị hoa hồng nhỏ trước khi dùng dữ liệu thật.
